# Antisickling Activity of Banana, Apple and Grapefruit Extracts — Analysis Code

Reproducible data analysis for the Pharm.D. research project:

> Odibo, A.O. (2017). *In-vitro evaluation of the anti-sickling potential, ascorbic acid and phytochemical constituents of natural fruit extracts (Musa acuminata, Malus domestica and Citrus paradisi).* Department of Pharmaceutical Chemistry, Faculty of Pharmacy, University of Benin, Nigeria. Supervisor: Prof. Abiodun Falodun.

The script recomputes every derived value in Chapter 4 (Results) from the tabulated data and redraws the figures.

## Related publications

- Odibo, A.O., Akaniro, I.R. and Ubah, E.M. (2020). In vitro investigation of the antisickling properties of aqueous fruit extracts of *Citrus paradisi*, *Musa acuminata* and *Malus domestica*. *GSC Biological and Pharmaceutical Sciences*, 13(3): 203–209.
- Odibo, A.O., Akaniro, I.R. and Nnamocha, T.O. (2021). Quantitative assessment of the ascorbic acid contents of *Musa acuminata*, *Malus domestica* and *Citrus paradisi* via dichlorophenolindophenol and spectrophotometric analysis. *Asian Journal of Research in Botany*, 4(1): 46–51.
- Akaniro, I.R. and Odibo, A.O. (2021). Analysis of the phytochemical composition of three selected fruits: *Musa acuminata*, *Malus domestica* and *Citrus paradisi*. *African Journal of Biology and Medical Research*, 4(1): 18–28.

## Repository layout

```
data/
  antisickling.csv     % unsickled HbSS erythrocytes, 3 extracts × 4 concentrations × 4 times (Table 4.9)
  controls.csv         normal saline and p-hydroxybenzoic acid controls (Table 4.9d)
  phytochemicals.csv   alkaloids, flavonoids, saponins, phenolics, tannins, mean ± SD, n = 3 (Table 4.3)
  ascorbic_acid.csv    ascorbic acid content (Table 4.8) and pH (Table 4.6)
  calibration.csv      DCPIP calibration standards at 515 nm (Table 4.7)
src/
  analysis.py          the full analysis
results/               created when you run the script (CSV tables, PNG figures, report.txt)
```

## Running it

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python src/analysis.py
```

## What it computes

| Thesis item | Method |
|---|---|
| Table 4.3 | One-way ANOVA across fruits for each phytochemical class (from mean, SD, n) |
| Tables 4.4–4.5, Figs 4.1–4.3 | Rank order and percentage occurrence within each fruit |
| Table 4.7, Fig 4.4 | % absorbance decrease, linear calibration (y = 2.0653x − 1.5654, R² = 0.9669) |
| Table 4.8 | % of recommended daily intake (IOM 2000: 90 / 75 / 45 mg/day) |
| Table 4.10 | Mean, SD, range, CV, conditions ≥ 95 %, means by time and concentration |
| Table 4.11, Fig 4.9 | One-way ANOVA (F(2, 45) = 8.57, p = 0.0007), Tukey HSD, Kruskal–Wallis |
| Table 4.12 | Two-way ANOVA without replication (concentration × time) within each extract |
| Figs 4.5–4.8 | Time-course plots against positive and negative controls |

The script also reports Shapiro–Wilk and Levene tests as assumption checks.

## Notes and limitations

- **Analysis uses condition means.** The antisickling data are the mean of triplicate slides at each concentration–time condition; replicate-level counts were not available. Once per-slide counts are recovered, a full factorial ANOVA (extract × concentration × time) with replication would be more powerful.
- **Phytochemical ANOVA is approximate.** It is computed from published means and SDs. Several SDs are reported as 0.00 after rounding, so the very large F values are sensitive to rounding; the significance conclusions are unaffected.
- **Assumption checks.** Two of the three groups depart from normality (Shapiro–Wilk p < 0.05) and variances are unequal (Levene p = 0.001). The Kruskal–Wallis test, which does not assume either, reaches the same conclusion (H = 11.83, p = 0.003). A Welch ANOVA with Games–Howell post-hoc tests would be a reasonable alternative.
- The original analysis was done in GraphPad Prism; Python reproduces the reported values to the stated precision.

## Citation

If you use this code or data, please cite the thesis and the related publications above.
